﻿
namespace CarPrice.Model.Discount
{
    public class DiscountResult : DiscountModel
    {
        public bool IsSuccessful { get; set; }
        public string Message { get; set; }
    }
}
