﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarPrice.Model.Discount
{
    public class DiscountModel
    {
        public int Id { get; set; }

        public double Discount { get; set; }
    }
}
