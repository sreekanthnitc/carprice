﻿
namespace CarPrice.Types
{
    public static class TransactionErrorCode
    {
        public const int VehicleDoesNotExistError = 1001;
        public const int TaxesAndFees = 1002;
        public const int InvalidSSN = 1003;
 
    }
}
