﻿using CarPrice.Entity;
using CarPrice.Entity.TaxAndFees;
using CarPrice.Model.TaxesAndFees;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace CarPrice.Repositories.TaxesAndFees
{
    public class TaxesAndFeesRepository : ITaxesAndFeesRepository
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly DbSet<TaxesAndFeesEntity> _taxesAndFeesEntity;

        public TaxesAndFeesRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
            _taxesAndFeesEntity = _dbContext.Set<TaxesAndFeesEntity>();
        }

        public async Task<TaxesAndFeesEntity> Read(TaxesAndFeesRequestModel inputModel)
        {
            return await _taxesAndFeesEntity.AsNoTracking()
                .FirstOrDefaultAsync(e => e.Make == inputModel.Make && e.Model == inputModel.Model && e.Year == inputModel.Year);
        }
    }
}
