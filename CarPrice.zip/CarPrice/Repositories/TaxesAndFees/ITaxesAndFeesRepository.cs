﻿using CarPrice.Entity.TaxAndFees;
using CarPrice.Model.TaxesAndFees;
using System.Threading.Tasks;

namespace CarPrice.Repositories.TaxesAndFees
{
    public interface ITaxesAndFeesRepository
    {
        Task<TaxesAndFeesEntity> Read(TaxesAndFeesRequestModel inputModel);
    }
}
