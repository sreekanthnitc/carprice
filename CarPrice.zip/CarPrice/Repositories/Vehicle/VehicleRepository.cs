﻿using CarPrice.Entity.Vehicle;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CarPrice.Entity;

namespace CarPrice.Repositories.Vehicle
{
    public class VehicleRepository : IVehicleRepository
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly DbSet<VehicleEntity> _vehicleEntity;

        public VehicleRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
            _vehicleEntity = _dbContext.Set<VehicleEntity>();
        }

        public async Task<VehicleEntity> Read(int id)
        {
            return await _vehicleEntity.AsNoTracking()
                .FirstOrDefaultAsync(e => e.Id == id);
        }
    }
}
