﻿using System;
using System.Threading.Tasks;
using AutoMapper;
using CarPrice.Model.TaxesAndFees;
using CarPrice.Services.TaxesAndFees;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CarPrice.Controllers
{
    [Route("api/taxfee")]
    public class TaxesAndFeesController : Controller
    {
        private readonly ITaxesAndFeesCore _taxesAndFeesCore;

        public TaxesAndFeesController(ITaxesAndFeesCore taxesAndFeesCore, IMapper mapper)
        {
            _taxesAndFeesCore = taxesAndFeesCore ?? throw new ArgumentNullException(nameof(taxesAndFeesCore));
        }

        [HttpGet("taxesandfees")]
        public async Task<IActionResult> Get([FromBody] TaxesAndFeesRequestModel inputModel)
        {
            var TaxesAndFeesResult = await _taxesAndFeesCore.GeTaxAndFeesDetails(inputModel);
            return Ok(TaxesAndFeesResult);
        }
    }
}
