﻿using CarPrice.Model.TaxesAndFees;
using System.Threading.Tasks;

namespace CarPrice.Services.TaxesAndFees
{
    public interface ITaxesAndFeesCore
    {
        Task<TaxesAndFeesModel> GeTaxAndFeesDetails (TaxesAndFeesRequestModel inputModel);
    }
}
